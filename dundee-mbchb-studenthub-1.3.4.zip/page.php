<?php
	include(locate_template('index.php'));
?>
