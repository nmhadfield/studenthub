<a href="<?php echo($href)?>" target="_blank"><?php echo($text)?></a>

